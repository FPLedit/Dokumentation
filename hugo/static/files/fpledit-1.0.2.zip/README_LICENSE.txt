FPLedit Version 1.0.2

(c) 2015-2016 Manuel Huber
https://fahrplan.manuelhu.de/

FPledit darf f�r den nicht-kommerziellen Gebrauch (dies schlie�t die
Ver�ffentlichung damit erstellter Fahrpl�ne auf privaten Websites
ausdr�cklich ein) kostenlos heruntergeladen und verwendet werden.
Die Weitergabe oder Bereitstellung des Programms �ber eine �ffentliche
Plattform oder gegen Entgelt ist nur nach vorheriger Zustimmung des
Programmautors gestattet. Verweisen Sie bitte stattdessen auf die
offizielle Website des Programms.
Eine kommerzielle Nutzung des Programms bedarf meiner vorherigen Zustimmung.

FPledit ist ein Projekt, das prim�r auf (Modell-)Eisenbahnfreunde abzielt.
Die Fahrpl�ne sind nicht nach den Betriebsrichtlinien irgendeiner
Bahngesellschaft gestaltet und sind f�r den Betriebsdienst nicht geeignet!

Der Autor dieses Programms haftet nicht f�r Sch�den an Soft- oder
Hardware oder Verm�genssch�den, die durch das Benutzen des Programms entstehen,
es sei denn diese beruhen auf einem grob fahrl�ssigen oder vors�tzlichen
Handeln des Autors, seiner Erf�llungsgehilfen oder seiner gesetzlichen
Vertreter. F�r  Sch�den an der Gesundheit, dem K�rper oder dem Leben des
Nutzers haftet der Autor uneingeschr�nkt. Ebenso haftet er f�r die
Verletzung von Pflichten, die zur Erreichung des Vertragszwecks von besonderer
Bedeutung sind (Kardinalspflichten).