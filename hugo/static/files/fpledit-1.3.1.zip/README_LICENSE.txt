FPLedit Version 1.3.1

(c) 2015-2017 Manuel Huber
https://fahrplan.manuelhu.de/

FPledit darf für den nicht-kommerziellen Gebrauch (dies schließt die
Veröffentlichung damit erstellter Fahrpläne auf privaten Websites
ausdrücklich ein) kostenlos heruntergeladen und verwendet werden.
Die Weitergabe oder Bereitstellung des Programms über eine öffentliche
Plattform oder gegen Entgelt ist nur nach vorheriger Zustimmung des
Programmautors gestattet. Verweisen Sie bitte stattdessen auf die
offizielle Website des Programms.
Eine kommerzielle Nutzung des Programms bedarf meiner vorherigen Zustimmung.

FPledit ist ein Projekt, das primär auf (Modell-)Eisenbahnfreunde abzielt.
Die Fahrpläne sind nicht nach den Betriebsrichtlinien irgendeiner
Bahngesellschaft gestaltet und sind für den Betriebsdienst nicht geeignet!

Der Autor dieses Programms haftet nicht für Schäden an Soft- oder
Hardware oder Vermögensschäden, die durch das Benutzen des Programms entstehen,
es sei denn diese beruhen auf einem grob fahrlässigen oder vorsälichen
Handeln des Autors, seiner Erfüllungsgehilfen oder seiner gesetzlichen
Vertreter. Für Schäden an der Gesundheit, dem Körper oder dem Leben des
Nutzers haftet der Autor uneingeschränkt. Ebenso haftet er für die
Verletzung von Pflichten, die zur Erreichung des Vertragszwecks von besonderer
Bedeutung sind (Kardinalspflichten).