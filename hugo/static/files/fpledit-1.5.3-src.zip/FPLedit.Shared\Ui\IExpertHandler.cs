﻿using System;

namespace FPLedit.Shared.Ui
{
    public interface IExpertHandler
    {
        void SetExpertMode(bool enabled);
    }
}
