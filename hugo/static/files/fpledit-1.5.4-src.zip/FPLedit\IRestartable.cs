﻿namespace FPLedit
{
    public interface IRestartable
    {
        void RestartWithCurrentFile();
    }
}
