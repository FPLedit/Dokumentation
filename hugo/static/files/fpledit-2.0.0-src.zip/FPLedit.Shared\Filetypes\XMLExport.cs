﻿using FPLedit.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace FPLedit.Shared.Filetypes
{
    public class XMLExport : IExport
    {
        public string Filter => "Fahrplan Dateien (*.fpl)|*.fpl";

        private XElement BuildNode(XMLEntity node)
        {
            XElement elm = new XElement(node.XName);
            if (node.Value != null)
                elm.SetValue(node.Value);
            foreach (var attr in node.Attributes)
                elm.SetAttributeValue(attr.Key, attr.Value);
            foreach (var ch in node.Children)
                elm.Add(BuildNode(ch));
            return elm;
        }

        public bool Export(Timetable tt, string filename, IInfo info)
        {
            bool debug = info.Settings.Get<bool>("xml.indent");
#if DEBUG
            debug = true;
#endif
            try
            {
                var ttElm = BuildNode(tt.XMLEntity);

                using (var writer = new XmlTextWriter(filename, new UTF8Encoding(false)))
                {
                    if (debug)
                        writer.Formatting = Formatting.Indented;
                    ttElm.Save(writer);
                }
                return true;
            }
            catch (Exception ex)
            {
                info.Logger.Error("XMLExport: " + ex.Message);
                return false;
            }
        }
    }
}
