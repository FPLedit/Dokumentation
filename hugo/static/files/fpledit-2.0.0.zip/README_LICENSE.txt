FPLedit Version 2.0.0

(c) 2015-2018 Manuel Huber
https://fahrplan.manuelhu.de/

FPLedit darf für den nicht-kommerziellen Gebrauch (dies schließt die
Veröffentlichung damit erstellter Fahrpläne auf privaten Websites
ausdrücklich ein) kostenlos heruntergeladen und verwendet werden. Die
Weitergabe oder Bereitstellung des Programms über eine öffentliche
Plattform oder gegen Entgelt ist nur nach vorheriger Zustimmung des
Programmautors gestattet. Verweisen Sie bitte stattdessen auf die
offizielle Website des Programms.
Eine kommerzielle Nutzung des Programms bedarf meiner vorherigen
Zustimmung.

FPLedit ist ein Projekt, das primär auf (Modell-)Eisenbahnfreunde abzielt.
Die Fahrpläne sind nicht nach den Betriebsrichtlinien irgendeiner
Bahngesellschaft gestaltet und sind für den Betriebsdienst nicht geeignet!

Der Autor dieses Programms haftet nicht für Schäden an Soft- oder Hardware
oder Vermögensschäden, die durch das Benutzen des Programms entstehen, es
sei denn diese beruhen auf einem grob fahrlässigen oder vorsätzlichen
Handeln des Autors, seiner Erfüllungsgehilfen oder seiner gesetzlichen
Vertreter. Für Schäden an der Gesundheit, dem Körper oder dem Leben des
Nutzers haftet der Autor uneingeschränkt. Ebenso haftet er für die
Verletzung von Pflichten, die zur Erreichung des Vertragszwecks von
besonderer Bedeutung sind (Kardinalspflichten).

SOURCECODE von FPLedit
======================
Der Sourcecode von FPLedit darf ebenfalls nach den oben genannten
Bestimmungen verwendet werden, damit ist die Veröffentlichung des gesamten,
unveränderten Sourcecodes nicht gestattet. Die Verwendung von (Teilen des)
Sourcecodes für eigene, auf FPLedit aufbauende Projekte (Erweiterungen) ist
ausdrücklich gestattet, solange der oben stehende Copyright-Hinweis auch im
neuen Gesamtwerk zu finden ist.

EINGEBUNDENE BIBLIOTHEKEN
=========================
FPLedit verwendet die Bibliothek Eto zur Darstellung der
Benutzerschnittstelle:

The BSD-3 License.

AUTHORS
Copyright © 2011-2018 Curtis Wensley. All Rights Reserved.
Copyright © 2012-2013 Vivek Jhaveri. All Rights Reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted
provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions
   and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions
   and the following disclaimer in the documentation and/or other materials
provided with the
   distribution.

3. The name of the author may not be used to endorse or promote products
derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

