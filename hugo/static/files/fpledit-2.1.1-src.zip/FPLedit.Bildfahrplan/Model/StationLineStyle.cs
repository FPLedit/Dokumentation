﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FPLedit.Bildfahrplan.Model
{
    public enum StationLineStyle
    {
        None = 0,
        Normal = 1,
        Cubic = 2
    }
}
